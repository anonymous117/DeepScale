# Extra-Deep

Extra-Deep is a performance analysis tool for distirbuted deep learning applications written in Python. It enables the users and developers to model the training performance of their deep learning application as a function of one or several input/configuration parameters such as the number of MPI ranks the application is executed with, the batch size per worker (rank), or the trained network configuration (architecture). Though Extra-Deep offers a variety of usefull tools and features for performance analysis:

* Automatic instrumentation of user written code
* GUI tool for performance analysis with visualizations
* Command line tool for performance analysis on clusters 


For further information please see our paper: [1. Installing Extra-Deep](#link)

## Index:

[1. Installing Extra-Deep](#anchor1)

[2. Instrument your code/application](#anchor2)

[3. Profile your applications training performance](#anchor3)


## 1. Installing Extra-Deep
<a name="anchor1"></a>

If you are on Linux and do install Extra-Deep into `~/.local/bin` don't forget to add it to your to your `$PATH` with `export PATH="$HOME/.local/bin:$PATH"`. Otherwise the `extradeep` command is not found.

### 1.a. Building the package locally with symlink

Installation option one is to build Extra-Deep from source by cloning our GitHub repository and the build and install it using the following commands:

* `git clone https://git.rwth-aachen.de/ritter/extradeep`
* `cd extradeep`
* `python setup.py sdist bdist_wheel`
* `cd ..`
* `pip install -e extradeep/`


## 2. Instrument your code/application
<a name="anchor2"></a>

Extra-Deep features a instrumentation tool to instrument your deep learning code. To instrument your code execute the following command in the folder where the main method of your application is. The instrumenter will create a new folder containing the instrumented version of the code. Specifying an output path is optional.

`extradeep_instrumenter <main_method_file_path> --out <output_folder_path>`

The instrumenter will only instrument user defined code and no library function from tensorflow etc. For improved coverage and a better performance analysis you should write your code in an object oriented style using functions and classes. Currently the instrumenter can only instrument the code inside user defined functions. To properly instrument the callstack of the user defined functions all your code files of the application have to be in the same root dir and as defined in the import statements in your python code. The test folder `test/sample_code/` features a sample code of a deep learning application written in python using tensorflow that can be instrumented. The automatic and manual instrumentation shown here works only for code written in python. The DL framework does not matter. You can use TensorFlow, PyTorch or similar frameworks.

You can run `extradeep_instrumenter test/main.py --out test/` in the root dir of extradeep repository to try it out and see how the sample code in `test/sample_code/` is instrumented automatically.

Depending on how your code is written the automatic instrumenter might not be able to cover all of the code regions of interest. Therefore, you can instrument sections of your code not covered by the automated instrumenter, or regions of interest for you, manually using the following methods:

```python
@nvtx.annotate(message="my_message", color="blue")
def my_func():
    pass
```

```python
rng = nvtx.start_range(message="my_message", color="blue")
# ... do something ... #
nvtx.end_range(rng)
```

```python
with nvtx.annotate(message="my_message", color="green"):
    pass
```

```python
try:
    something()
except SomeError():
    nvtx.mark(message="some error occurred", color="red")
    # ... do something else ...
```

For the instrumentation of user defined code the nvtx python package is required. It can be installed with:

`python -m pip install nvtx`

For further documentation please see [nvtx](https://nvtx.readthedocs.io/en/latest/index.html).

## 3. Profile your applications training performance
<a name="anchor3"></a>

### 3.a. Profiling runtime, bytes... with NsightSystems

```
srun nsys profile -t nvtx,cuda,mpi,cublas,cudnn --mpi-impl openmpi -b none --cpuctxsw none -f true -x true -o cifar100.p<nr_mpi_ranks>.r<repetition_nr>.mpi%q{SLURM_PROCID} python -u main.py -p 2 -n resnet18 -r 1
```


## 4. Model creation

Explained in the GUI and command line version help messages.