# This file is part of the Extra-Deep software (https://github.com/extra-deep)
#
# Copyright (c) 2022, Technical University of Darmstadt, Germany
#
# This software may be modified and distributed under the terms of a BSD-style license.
# See the LICENSE file in the base directory for details.

import copy
import itertools
import logging
import warnings
from typing import List, Sequence

from extradeep.entities.functions import SingleParameterFunction
from extradeep.entities.hypotheses import SingleParameterHypothesis
from extradeep.entities.measurement import Measurement
from extradeep.entities.model import Model
from extradeep.entities.parameter import Parameter
from extradeep.entities.terms import CompoundTerm
from extradeep.modelers.abstract_modeler import SingularModeler
from extradeep.modelers.modeler_options import modeler_options
from extradeep.modelers.single_parameter.abstract_base import AbstractSingleParameterModeler


@modeler_options
class SingleParameterModeler(AbstractSingleParameterModeler, SingularModeler):
    """
    This class represents the modeler for single parameter functions.
    In order to create a model measurements at least 5 points are needed.
    The result is either a constant function or one based on the PMNF.
    """

    NAME = 'Basic'
    DESCRIPTION = "Modeler for single-parameter models; traverses the search-space of all defined hypotheses."

    allow_log_terms = modeler_options.add(True, bool, 'Allows models with logarithmic terms',
                                          on_change=lambda self, v: self._exponents_changed())
    poly_exponents = modeler_options.add('', str, 'Set of polynomial exponents. Use comma separated list.',
                                         name='Polynomial', on_change=lambda self, v: self._exponents_changed())
    log_exponents = modeler_options.add('', str, 'Set of logarithmic exponents. Use comma separated list.',
                                        name='Logarithmic', on_change=lambda self, v: self._exponents_changed())
    retain_default_exponents = modeler_options.add(False, bool,
                                                   'If set the default exponents are added to the given ones.',
                                                   name='Retain default',
                                                   on_change=lambda self, v: self._exponents_changed())
    force_combination_exponents = modeler_options.add(False, bool,
                                                      'If set the exact combination of exponents is forced.',
                                                      name='Force combination',
                                                      on_change=lambda self, v: self._exponents_changed())
    allow_negative_exponents = modeler_options.add(False, bool,
                                                   'If set adds neagtive exponents for strong scaling.',
                                                   name='Negative exponents',
                                                   on_change=lambda self, v: self._exponents_changed())
    modeler_options.group('Exponents', poly_exponents, log_exponents, retain_default_exponents,
                          force_combination_exponents, allow_negative_exponents)

    def __init__(self):
        """
        Initialize SingleParameterModeler object.
        """
        super().__init__(use_median=False)

        # value for the minimum number of measurement points required for modeling
        self.min_measurement_points = 4

        # create the building blocks for the hypothesis
        self.hypotheses_building_blocks: List[CompoundTerm] = self.create_default_building_blocks(
            self.allow_log_terms, self.allow_negative_exponents)

    def _exponents_changed(self):
        def parse_expos(expos):
            expos = expos.split(',')
            result = []
            for e in expos:
                try:
                    result.append(float(e) if '.' in e else int(e))
                except ValueError:
                    pass
            return result

        polyexpos = parse_expos(self.poly_exponents)
        logexpos = parse_expos(self.log_exponents)

        if len(polyexpos) > 0 or len(logexpos) > 0:
            self.hypotheses_building_blocks = self.generate_building_blocks(polyexpos, logexpos,
                                                                            self.force_combination_exponents)
            if self.retain_default_exponents:
                self.hypotheses_building_blocks.extend(
                    self.create_default_building_blocks(self.allow_log_terms, self.allow_negative_exponents))
        else:
            self.hypotheses_building_blocks = self.create_default_building_blocks(self.allow_log_terms,
                                                                                  self.allow_negative_exponents)

    def get_matching_hypotheses(self, measurements: Sequence[Measurement]):
        """Removes log terms from the returned hypotheses_building_blocks, if those cannot describe the measurements."""

        if self.are_measurements_log_capable(measurements, self.allow_negative_exponents):
            return self.hypotheses_building_blocks

        if any(t.term_type == "logarithm" for compound_term in self.hypotheses_building_blocks
               for t in compound_term.simple_terms):
            warnings.warn("Your measurements contained a point value below one, therefore, "
                          "Extra-P does not use logarithmic terms for modeling.")

        return [compound_term
                for compound_term in self.hypotheses_building_blocks
                if not any(t.term_type == "logarithm"
                           for t in compound_term.simple_terms)
                ]

    @staticmethod
    def create_default_building_blocks(allow_log_terms, allow_negative_exponents=False):
        """
        Creates the default building blocks for the single parameter hypothesis
        that will be used during the search for the best hypothesis.
        """

        if allow_log_terms:
            exponents = [(0, 1, 1),
                         (0, 1, 2),
                         (1, 4, 0),
                         (1, 3, 0),
                         (1, 4, 1),
                         (1, 3, 1),
                         (1, 4, 2),
                         (1, 3, 2),
                         (1, 2, 0),
                         (1, 2, 1),
                         (1, 2, 2),
                         (2, 3, 0),
                         (3, 4, 0),
                         (2, 3, 1),
                         (3, 4, 1),
                         (4, 5, 0),
                         (2, 3, 2),
                         (3, 4, 2),
                         (1, 1, 0),
                         (1, 1, 1),
                         (1, 1, 2),
                         (5, 4, 0),
                         (5, 4, 1),
                         (4, 3, 0),
                         (4, 3, 1),
                         (3, 2, 0),
                         (3, 2, 1),
                         (3, 2, 2),
                         (5, 3, 0),
                         (7, 4, 0),
                         (2, 1, 0),
                         (2, 1, 1),
                         (2, 1, 2),
                         (9, 4, 0),
                         (7, 3, 0),
                         (5, 2, 0),
                         (5, 2, 1),
                         (5, 2, 2),
                         (8, 3, 0),
                         (11, 4, 0),
                         (3, 1, 0),
                         (3, 1, 1)]
            if allow_negative_exponents:
                exponents += [(-0, 1, -1),
                              (-0, 1, -2),
                              (-0, 1, -3),
                              (-1, 4, -1),
                              (-1, 3, -1),
                              (-1, 4, -2),
                              (-1, 3, -2),
                              (-1, 4, -3),
                              (-1, 3, -3),
                              (-1, 2, -1),
                              (-1, 2, -2),
                              (-1, 2, -3),
                              (-2, 3, -1),
                              (-3, 4, -1),
                              (-2, 3, -2),
                              (-3, 4, -2),
                              (-2, 3, -3),
                              (-3, 4, -3),
                              (-1, 1, -1),
                              (-1, 1, -2),
                              (-1, 1, -3),
                              (-5, 4, -1),
                              (-4, 3, -1),
                              (-3, 2, -1),
                              (-5, 4, -3),
                              (-4, 3, -3),
                              (-3, 2, -3),
                              (-3, 2, -2),
                              (-2, 1, -1),
                              (-2, 1, -2),
                              (-2, 1, -3),
                              (-5, 2, -1),
                              (-5, 2, -2),
                              (-5, 2, -3),
                              (-3, 1, -1),
                              (-3, 1, -2),
                              (-3, 1, -3)]

        else:
            exponents = [(1, 4, 0),
                         (1, 3, 0),
                         (1, 2, 0),
                         (2, 3, 0),
                         (3, 4, 0),
                         (4, 5, 0),
                         (1, 1, 0),
                         (5, 4, 0),
                         (4, 3, 0),
                         (3, 2, 0),
                         (5, 3, 0),
                         (7, 4, 0),
                         (2, 1, 0),
                         (9, 4, 0),
                         (7, 3, 0),
                         (5, 2, 0),
                         (8, 3, 0),
                         (11, 4, 0),
                         (3, 1, 0)]
            # These were used for relearn
            #print("Negative exponents allowed: ", allow_negative_exponents)
            if allow_negative_exponents:
                exponents += [(-1, 4, 0),
                              (-1, 3, 0),
                              (-1, 2, 0),
                              (-2, 3, 0),
                              (-3, 4, 0),
                              (-4, 5, 0),
                              (-1, 1, 0),
                              (-5, 4, 0),
                              (-4, 3, 0),
                              (-3, 2, 0),
                              (-5, 3, 0),
                              (-7, 4, 0),
                              (-2, 1, 0),
                              (-9, 4, 0),
                              (-7, 3, 0),
                              (-5, 2, 0),
                              (-8, 3, 0),
                              (-11, 4, 0),
                              (-3, 1, 0)]

        hypotheses_building_blocks = [CompoundTerm.create(*e) for e in exponents]
        # print the hypothesis building blocks, compound terms in debug mode
        if logging.getLogger().isEnabledFor(logging.DEBUG):
            parameter = Parameter('p')
            for i, compound_term in enumerate(hypotheses_building_blocks):
                logging.debug(
                    f"Compound term {i}: {compound_term.to_string(parameter)}")

        return hypotheses_building_blocks

    @staticmethod
    def generate_building_blocks(poly_exponents, log_exponents, force_combination=False):
        if force_combination:
            exponents = itertools.product(poly_exponents, log_exponents)
        else:
            exponents = itertools.chain(
                itertools.product(poly_exponents, [0]),
                itertools.product([0], log_exponents),
                itertools.product(poly_exponents, log_exponents))

        return [CompoundTerm.create(*e) for e in exponents if not e == (0, 0)]

    def build_hypotheses(self, measurements):
        """
        Builds the next hypothesis that should be analysed based on the given compound term.
        """
        hypotheses_building_blocks = self.get_matching_hypotheses(measurements)

        # search for the best hypothesis over all functions that can be build with the basic building blocks
        # using leave one out crossvalidation
        for i, compound_term in enumerate(hypotheses_building_blocks):
            #print(compound_term)
            #compound_terms = []
            #compound_terms.append(compound_term)
            #compound_terms.append(compound_term)
            # create next function that will be analyzed
            next_function = SingleParameterFunction(copy.copy(compound_term))
            #next_function = SingleParameterFunction(copy.copy(compound_terms))

            #print(next_function)

            # create single parameter hypothesis from function
            yield SingleParameterHypothesis(next_function, self.use_median)

    def create_model(self, measurements: Sequence[Measurement]):
        """
        Create a model for the given callpath and metric using the given data.
        """

        # check if the number of measurements satisfies the requirements of the modeler (>=5)
        if len(measurements) < self.min_measurement_points:
            warnings.warn(
                "Number of measurements for a parameter needs to be at least 5 in order to create a performance model.")
            # return None

        # create a constant model
        constant_hypothesis, constant_cost = self.create_constant_model(measurements)
        logging.debug("Constant model: " + constant_hypothesis.function.to_string())
        logging.debug("Constant model cost: " + str(constant_cost))

        # use constant model when cost is 0
        if constant_cost == 0:
            logging.debug("Using constant model.")
            return Model(constant_hypothesis)

        # otherwise start searching for the best hypothesis based on the PMNF
        else:
            logging.debug("Searching for a single-parameter model.")
            # search for the best single parameter hypothesis
            hypotheses_generator = self.build_hypotheses(measurements)
            best_hypothesis = self.find_best_hypothesis(hypotheses_generator, constant_cost, measurements,
                                                        constant_hypothesis)
            return Model(best_hypothesis)
